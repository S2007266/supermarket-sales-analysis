"""
generate_sample_data.py
------------------------
Creates a sample 'supermarket_sales.csv' file with 500 transactions so that
supermarket_sales_analysis.py can be run end-to-end without needing an
external dataset. If you already have your own supermarket sales CSV,
skip this script and just point the analysis script at your file instead.

Columns generated:
    InvoiceID, Branch, City, CustomerType, Product, Category,
    Quantity, UnitPrice, PaymentMethod, Rating
"""

import random
import pandas as pd

random.seed(42)

BRANCHES = {"A": "Delhi", "B": "Bengaluru", "C": "Mumbai"}
CUSTOMER_TYPES = ["Member", "Normal"]
PAYMENT_METHODS = ["UPI", "Cash", "Card"]

CATEGORY_PRODUCTS = {
    "Beverages": ["Cola", "Orange Juice", "Mineral Water", "Coffee", "Tea"],
    "Dairy": ["Milk", "Cheese", "Butter", "Yogurt", "Paneer"],
    "Snacks": ["Chips", "Biscuits", "Namkeen", "Chocolate"],
    "Grocery": ["Rice", "Wheat Flour", "Sugar", "Cooking Oil", "Pulses"],
    "Fruits & Vegetables": ["Apple", "Banana", "Tomato", "Onion", "Potato"],
}

rows = []
for i in range(1, 501):
    branch = random.choices(["A", "B", "C"], weights=[0.3, 0.3, 0.4])[0]
    category = random.choice(list(CATEGORY_PRODUCTS.keys()))
    product = random.choice(CATEGORY_PRODUCTS[category])
    quantity = random.randint(1, 10)
    unit_price = round(random.uniform(20, 500), 2)
    rows.append({
        "InvoiceID": f"INV-{1000 + i}",
        "Branch": branch,
        "City": BRANCHES[branch],
        "CustomerType": random.choice(CUSTOMER_TYPES),
        "Product": product,
        "Category": category,
        "Quantity": quantity,
        "UnitPrice": unit_price,
        "PaymentMethod": random.choices(
            PAYMENT_METHODS, weights=[0.45, 0.30, 0.25]
        )[0],
        "Rating": round(random.uniform(2.5, 5.0), 1),
    })

df = pd.DataFrame(rows)
df.to_csv("supermarket_sales.csv", index=False)
print("Sample dataset created: supermarket_sales.csv")
print(df.head())
