"""
Supermarket Sales Analysis
===========================
Data Analytics Project

This script analyzes supermarket sales data and answers key business
questions about products, branches, categories, customers, payment
methods, and ratings.

Steps:
    1. Load the CSV dataset.
    2. Check for missing / incorrect values.
    3. Calculate Sales = Quantity x Unit Price.
    4. Group and summarize the data (totals, counts, averages).
    5. Create charts to compare the results.
    6. Print business insights.

Usage:
    python supermarket_sales_analysis.py [path_to_csv]

    If no path is given, it defaults to "supermarket_sales.csv" in the
    current folder. Run generate_sample_data.py first if you don't have
    a real dataset handy.
"""

import sys
import os
import pandas as pd
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------
# 0. Setup
# ---------------------------------------------------------------------
DATA_PATH = sys.argv[1] if len(sys.argv) > 1 else "supermarket_sales.csv"
OUTPUT_DIR = "charts"
os.makedirs(OUTPUT_DIR, exist_ok=True)

pd.set_option("display.float_format", lambda x: f"{x:,.2f}")


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


# ---------------------------------------------------------------------
# 1. Load the dataset
# ---------------------------------------------------------------------
section("1. Loading Dataset")

if not os.path.exists(DATA_PATH):
    raise FileNotFoundError(
        f"Could not find '{DATA_PATH}'. Run generate_sample_data.py first, "
        "or pass the path to your own CSV as an argument."
    )

df = pd.read_csv(DATA_PATH)
print(f"Loaded {len(df)} rows from '{DATA_PATH}'")
print(df.head())

# ---------------------------------------------------------------------
# 2. Data cleaning / validation
# ---------------------------------------------------------------------
section("2. Checking Data Quality")

print("Missing values per column:")
print(df.isnull().sum())

# Drop rows with missing values in essential columns
essential_cols = ["Quantity", "UnitPrice"]
before = len(df)
df = df.dropna(subset=essential_cols)
after = len(df)
if before != after:
    print(f"Dropped {before - after} rows with missing Quantity/UnitPrice.")

# Remove rows with non-positive quantity or price (data errors)
bad_rows = df[(df["Quantity"] <= 0) | (df["UnitPrice"] <= 0)]
if len(bad_rows) > 0:
    print(f"Removing {len(bad_rows)} rows with invalid Quantity/UnitPrice.")
    df = df[(df["Quantity"] > 0) & (df["UnitPrice"] > 0)]

# ---------------------------------------------------------------------
# 3. Calculate Sales
# ---------------------------------------------------------------------
section("3. Calculating Sales")

df["Sales"] = df["Quantity"] * df["UnitPrice"]
print(df[["Product", "Quantity", "UnitPrice", "Sales"]].head())

# ---------------------------------------------------------------------
# 4. Group & summarize
# ---------------------------------------------------------------------
section("4. Grouped Summaries")

sales_by_product = (
    df.groupby("Product")["Sales"].sum().sort_values(ascending=False)
)
sales_by_branch = (
    df.groupby("Branch")["Sales"].sum().sort_values(ascending=False)
)
sales_by_category = (
    df.groupby("Category")["Sales"].sum().sort_values(ascending=False)
)
payment_counts = df["PaymentMethod"].value_counts()
avg_spend_by_customer_type = df.groupby("CustomerType")["Sales"].mean()
avg_rating = df["Rating"].mean()

print("\nTop 5 products by sales:")
print(sales_by_product.head())

print("\nSales by branch:")
print(sales_by_branch)

print("\nSales by category:")
print(sales_by_category)

print("\nPayment method usage:")
print(payment_counts)

print("\nAverage spend by customer type:")
print(avg_spend_by_customer_type)

print(f"\nAverage customer rating: {avg_rating:.2f} / 5")

# ---------------------------------------------------------------------
# 5. Charts
# ---------------------------------------------------------------------
section("5. Creating Charts")

# 5.1 Top 10 products by sales
plt.figure(figsize=(9, 5))
sales_by_product.head(10).plot(kind="bar", color="teal")
plt.title("Top 10 Products by Sales")
plt.ylabel("Sales")
plt.xlabel("Product")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "top_products.png"))
plt.close()

# 5.2 Sales by branch
plt.figure(figsize=(6, 5))
sales_by_branch.plot(kind="bar", color="orange")
plt.title("Total Sales by Branch")
plt.ylabel("Sales")
plt.xlabel("Branch")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "sales_by_branch.png"))
plt.close()

# 5.3 Sales by category
plt.figure(figsize=(7, 5))
sales_by_category.plot(kind="bar", color="seagreen")
plt.title("Total Sales by Category")
plt.ylabel("Sales")
plt.xlabel("Category")
plt.xticks(rotation=30, ha="right")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "sales_by_category.png"))
plt.close()

# 5.4 Payment method share
plt.figure(figsize=(6, 6))
payment_counts.plot(kind="pie", autopct="%1.1f%%", startangle=90)
plt.title("Payment Method Share")
plt.ylabel("")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "payment_methods.png"))
plt.close()

# 5.5 Average spend: Member vs Normal
plt.figure(figsize=(5, 5))
avg_spend_by_customer_type.plot(kind="bar", color=["#4C72B0", "#DD8452"])
plt.title("Average Spend: Member vs Normal")
plt.ylabel("Average Sales")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "avg_spend_customer_type.png"))
plt.close()

# 5.6 Rating distribution
plt.figure(figsize=(6, 5))
df["Rating"].plot(kind="hist", bins=10, color="purple", edgecolor="white")
plt.title("Customer Rating Distribution")
plt.xlabel("Rating")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "rating_distribution.png"))
plt.close()

print(f"Charts saved to '{OUTPUT_DIR}/' folder.")

# ---------------------------------------------------------------------
# 6. Business insights (auto-generated from the data)
# ---------------------------------------------------------------------
section("6. Key Business Insights")

top_product = sales_by_product.idxmax()
top_product_sales = sales_by_product.max()

top_branch = sales_by_branch.idxmax()
top_branch_sales = sales_by_branch.max()

top_category = sales_by_category.idxmax()
top_category_sales = sales_by_category.max()

top_payment = payment_counts.idxmax()
top_payment_count = payment_counts.max()

member_avg = avg_spend_by_customer_type.get("Member", float("nan"))
normal_avg = avg_spend_by_customer_type.get("Normal", float("nan"))

print(f"- Highest-selling product: {top_product} (Sales: {top_product_sales:,.2f})")
print(f"- Best-performing branch: {top_branch} (Sales: {top_branch_sales:,.2f})")
print(f"- Best-selling category: {top_category} (Sales: {top_category_sales:,.2f})")
print(f"- Most used payment method: {top_payment} ({top_payment_count} transactions)")
print(f"- Avg. Member spend: {member_avg:,.2f} | Avg. Normal spend: {normal_avg:,.2f}")
print(f"- Average customer rating: {avg_rating:.2f} / 5")

section("Done")
print("Analysis complete. See the 'charts' folder for visualizations.")
